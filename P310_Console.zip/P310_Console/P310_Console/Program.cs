﻿using System;

namespace P310_Console
{
    class Program
    {
        static void Main()
        {
            #region boxing & unboxing
            //int n = 10;
            //object obje = "dfgfd"; //boxing

            //int? m = obje as int?;

            //Console.WriteLine(m);
            #endregion

            Queue queue = new Queue(2);
            queue.Enqueue("Samir");
            queue.Enqueue("Perviz");

            queue.Dequeue();
            queue.Dequeue();
        }
    }

    class Queue
    {
        private readonly string[] _queue;
        private int tail = 0;
        private int head = 0;

        public Queue(uint len)
        {
            _queue = new string[len];
        }

        /// <summary>
        /// This method will be used to add element to the end of the queue
        /// </summary>
        /// <param name="item">Element to add to the queue</param>
        public void Enqueue(string item)
        {
            _queue[tail++] = item;
        }

        public string Dequeue()
        {
            return _queue[head++];
        }

    }

    class Person
    {

    }
}